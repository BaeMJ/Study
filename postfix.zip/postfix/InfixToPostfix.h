#ifndef __INFIX_TO_POSTFIX_H__
#define __INFIX_TO_POSTFIX_H__
#include "ListBaseStack.h"

Stack oprStack;
Stack cal;


char postfix[64];
//char *postfix;

void InToPost(char *infix);
void calculate(char *postfix);
int arithmetic(char opr, int opn1, int opn2);

int priority(char opr);
int SignToNum(char opr);
char NumToSign(int num);

#endif