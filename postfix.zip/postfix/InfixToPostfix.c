#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "InfixToPostfix.h"

void InToPost(char *infix){

	int i = 0;	//infix index
	int j = 0;	//postfix index
	char opr = 0;


//	postfix = (char *)malloc(sizeof(char)*strlen(infix));
 	for (i = 0; i < 64; i++){
 		postfix[i] = NULL;
 	}
	
	for (i = 0; i < strlen(infix); i++){
		if (infix[i] >= '1' && infix[i] <= '9'){
			postfix[j++] = infix[i];
		}

		else if (infix[i] == '+' || infix[i] == '-' || infix[i] == '*' || infix[i] == '/'){
			opr = infix[i];

			if (SIsEmpty(&oprStack)){
				SPush(&oprStack, SignToNum(opr));
			}	//������ ���� ������� �ٷ� push
			
			else{
				if (priority(opr) > priority(NumToSign(SPeek(&oprStack))) ){
					SPush(&oprStack, SignToNum(opr));
				}
				else{
					while (priority(opr) > priority(NumToSign(SPeek(&oprStack))) ){
						postfix[j++] = NumToSign(SPop(&oprStack));
					}
					SPush(&oprStack, priority(opr));
				}
			}	//������ ���ÿ� �켱���� �� ���� ������ ������ ���� push
		}

		else if (infix[i] == '('){
			opr = infix[i];
			SPush(&oprStack, SignToNum(opr));
		}

		else if (infix[i] == ')'){
			
			while (SPeek(&oprStack) != 5){
				postfix[j++] = NumToSign(SPop(&oprStack));
			}	//���� ��ȣ ������ ������ pop
			SPop(&oprStack);	//���� ��ȣ ���ÿ��� ����
		}

		else{
			printf("Error\n");
			exit(-1);
		}

	}

	while (!SIsEmpty(&oprStack)){
		postfix[j++] = NumToSign(SPop(&oprStack));
	}


}

void calculate(char *postfix){

	int i = 0;
	int opn1 = 0, opn2 = 0;
	char opr = 0;
	int result = 0;

	for (int i = 0; i < strlen(postfix); i++){
		
		if (postfix[i] >= '1' && postfix[i] <= '9'){
			SPush(&cal, postfix[i]-'0');	//char->int
		}	//�����̸� cal ���ÿ� push

		else{
			opr = postfix[i];
			opn2 = SPop(&cal);
			opn1 = SPop(&cal);

			result = arithmetic(opr, opn1, opn2);

			SPush(&cal, result);
		}	//�������̸� �տ� �� ���� pop�Ͽ� ���� �� ��� �� push
	}

	printf("Result = %d\n", SPop(&cal));

}

int arithmetic(char opr, int opn1, int opn2){

	if (opr == '+')
		return (opn1 + opn2);
	else if (opr == '-')
		return (opn1 - opn2);
	else if (opr == '*')
		return (opn1 * opn2);
	else if (opr == '/')
		return (opn1 / opn2);
	else
		return -1;

}

int priority(char opr){

	switch (opr){
	case '+': return 1;
	case '-': return 1;
	case '*': return 2;
	case '/': return 2;
	case '(': return 3;
	default: return -1;
	}
}

int SignToNum(char opr){

	switch (opr){
	case '+': return 1;
	case '-': return 2;
	case '*': return 3;
	case '/': return 4;
	case '(': return 5;
	default: return -1;
	}
}

char NumToSign(int num){

	switch (num){
	case 1: return '+';
	case 2: return '-';
	case 3: return '*';
	case 4: return '/';
	default: return ' ';
	}
}
