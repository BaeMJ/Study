#include <stdio.h>

#include "ListBaseStack.h"
#include "InfixToPostfix.h"

int main(void)
{

	char *infix = NULL;

//	infix = "2+3*5";
	infix = "2+3*(5+1)";

	InToPost(infix);

	printf("infix: %s\n", infix);
	printf("postfix: %s\n", postfix);

	calculate(postfix);

	return 0;
}